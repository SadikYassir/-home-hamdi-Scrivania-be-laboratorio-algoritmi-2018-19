/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

/**
 *
 * @author soa96
 */
public class GraphTest {

    Graph<String, Float> graph;
    HashMap<String, HashMap<String, Float>> expexted;

    public GraphTest() {

    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        graph = new Graph<>();
        expexted = new HashMap<>();
        expexted.put("A", new HashMap<>());
        expexted.put("B", new HashMap<>());
        expexted.put("C", new HashMap<>());
        expexted.put("D", new HashMap<>());
        expexted.put("E", new HashMap<>());
        expexted.put("F", new HashMap<>());
        expexted.put("G", new HashMap<>());
        expexted.put("H", new HashMap<>());
        expexted.put("I", new HashMap<>());

        graph.addEdge("A", "B", (float) 4);
        expexted.get("A").put("B", (float) 4);
        expexted.get("B").put("A", (float) 4);

        graph.addEdge("A", "I", (float) 8);
        expexted.get("A").put("I", (float) 8);
        expexted.get("I").put("A", (float) 8);

        graph.addEdge("B", "C", (float) 8);
        expexted.get("B").put("C", (float) 8);
        expexted.get("C").put("B", (float) 8);

        graph.addEdge("B", "I", (float) 11);
        expexted.get("B").put("I", (float) 11);
        expexted.get("I").put("B", (float) 11);

        graph.addEdge("C", "D", (float) 7);
        expexted.get("C").put("D", (float) 7);
        expexted.get("D").put("C", (float) 7);

        graph.addEdge("C", "F", (float) 4);
        expexted.get("C").put("F", (float) 4);
        expexted.get("F").put("C", (float) 4);

        graph.addEdge("C", "H", (float) 2);
        expexted.get("C").put("H", (float) 2);
        expexted.get("H").put("C", (float) 2);

        graph.addEdge("D", "E", (float) 9);
        expexted.get("D").put("E", (float) 9);
        expexted.get("E").put("D", (float) 9);

        graph.addEdge("D", "F", (float) 14);
        expexted.get("D").put("F", (float) 14);
        expexted.get("F").put("D", (float) 14);

        graph.addEdge("E", "F", (float) 10);
        expexted.get("E").put("F", (float) 10);
        expexted.get("F").put("E", (float) 10);

        graph.addEdge("F", "G", (float) 2);
        expexted.get("F").put("G", (float) 2);
        expexted.get("G").put("F", (float) 2);

        graph.addEdge("G", "H", (float) 6);
        expexted.get("G").put("H", (float) 6);
        expexted.get("H").put("G", (float) 6);

        graph.addEdge("G", "I", (float) 1);
        expexted.get("G").put("I", (float) 1);
        expexted.get("I").put("G", (float) 1);

        graph.addEdge("H", "I", (float) 7);
        expexted.get("H").put("I", (float) 7);
        expexted.get("I").put("H", (float) 7);
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of addNode method, of class Graph.
     */
    @Test
    public void testAddNode() {
        graph.addNode("X");
        graph.addNode("Y");
        expexted.put("X", new HashMap<>());
        expexted.put("Y", new HashMap<>());

        assertThat(graph.getGraph(), is(expexted));
    }

    /**
     * Test of addEdge method, of class Graph.
     */
    @Test
    public void testAddEdge() {
        graph.addEdge("X", "Y", (float) 900);
        expexted.put("X", new HashMap<>());
        expexted.put("Y", new HashMap<>());
        expexted.get("X").put("Y", (float) 900);
        expexted.get("Y").put("X", (float) 900);

        assertThat(graph.getGraph(), is(expexted));
    }

    /**
     * Test of addEdge method when the Graph is directed.
     */
    @Test
    public void testAddEdgeDirected() {
        graph = new Graph<>(true);
        expexted = new HashMap<>();

        graph.addEdge("A", "B", (float) 100);
        expexted.put("A", new HashMap<>());
        expexted.put("B", new HashMap<>());
        expexted.get("A").put("B", (float) 100);

        assertThat(graph.getGraph(), is(expexted));
    }

    /**
     * Test of isDirect method, of class Graph.
     */
    @Test
    public void testIsDirect() {
        Graph instance = new Graph(true);
        boolean expResult = true;
        boolean result = instance.isDirect();
        assertEquals(expResult, result);

    }

    /**
     * Test of containsNode method, of class Graph.
     */
    @Test
    public void testContainsNode() {
        Graph instance = new Graph();
        instance.addNode("A");
        boolean expResult = true;
        boolean result = instance.containsNode("A");
        assertEquals(expResult, result);
    }

    /**
     * Test of containsEdge method, of class Graph.
     */
    @Test
    public void testContainsEdge() {
        Graph instance = new Graph();
        instance.addEdge("A", "B", (float) 5.0);
        boolean expResult = true;
        boolean result = instance.containsEdge("A", "B");
        assertEquals(expResult, result);

    }

    /**
     * Test of removeEdge method, of class Graph.
     */
    @Test
    public void testRemoveEdge() {
        graph = new Graph<>();
        expexted = new HashMap<>();
        expexted.put("A", new HashMap<>());
        expexted.put("B", new HashMap<>());
        graph.addEdge("A", "B", (float) 4);
        expexted.get("A").put("B", (float) 4);
        expexted.get("B").put("A", (float) 4);
        
        expexted.get("A").remove("B");
        expexted.get("B").remove("A");
        assertTrue(graph.removeEdge("A","B"));
        assertThat(graph.getGraph(), is(expexted));
    }

    @Test
    public void testRemoveEdgeNotPresent() {
        assertFalse(graph.removeEdge("A", "X"));
        assertThat(graph.getGraph(), is(expexted));
    }

    /**
     * Test of countNodes method, of classFGraph.
     */
    @Test
    public void testCountNodes() {
        assertEquals(9, graph.countNodes());
    }

    /**
     * Test of countEdges method, of class Graph.
     */
    @Test
    public void testCountEdges() {
        assertEquals(14, graph.countEdges());
    }

    /**
     * Test of getNodes method, of class Graph.
     */
    @Test
    public void testGetNodes() {
        Graph instance = graph;
        Set expResult = expexted.keySet();
        Set result = instance.getNodes();
        assertEquals(expResult, result);
    }

    /**
     * Test of getNeighbors method, of class Graph.
     */
    @Test
    public void testGetNeighbors() {
        Object node = "A";
        Graph instance = graph;
        HashMap expResult = expexted.get(node);
        HashMap result = instance.getNeighbors(node);
        assertEquals(expResult, result);
    }

    /**
     * Test of getEdgeWeight method, of class Graph.
     */
    @Test
    public void testGetEdgeWeight() {
        Graph instance = new Graph();
        instance.addEdge("A", "B", (float) 5.0);
        Object expResult = (float) 5.0;
        Object result = instance.getEdgeWeight("A", "B");
        assertEquals(expResult, result);
    }

    /**
     * Test of getWeight method , of class Graph
     */
    @Test
    public void testGetWeight() {
        assertEquals(93.0, graph.getWeight(), 0.5);
    }


    /*
    Test for not Weighted Graph
     */
    @Test
    public void testnotWeightedGraph() {
        graph = new Graph<>();
        graph.addEdge("A", "B", null);

        assertNull(graph.getWeight());
    }
}
