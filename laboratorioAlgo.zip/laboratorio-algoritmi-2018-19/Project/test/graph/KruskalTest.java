/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import static org.hamcrest.core.Is.is;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import unionfind.UnionFindSet;

/**
 *
 * @author yassir
 */
public class KruskalTest {

    Graph<String, Double> expResult;
    Graph<String, Double> grafo;
    UnionFindSet<String> uf;

    public KruskalTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        grafo = new Graph<>();
        uf = new UnionFindSet<>();

        grafo.addEdge("A", "B", 100.0);
        grafo.addEdge("A", "C", 70.0);
        grafo.addEdge("A", "D", 33.5);
        grafo.addEdge("C", "D", 22.1);

        expResult = new Graph(true);
        expResult.addEdge("A", "B", 100.0);
        expResult.addEdge("B", "A", 100.0);
        expResult.addEdge("A", "D", 33.5);
        expResult.addEdge("D", "A", 33.5);
        expResult.addEdge("D", "C", 22.1);
        expResult.addEdge("C", "D", 22.1);
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of MST method, of class Kruskal.
     */
    @Test
    public void testMST() {

        Kruskal instance = new Kruskal(grafo, uf);
        grafo = instance.MST();
        assertThat(expResult.getGraph(), is(grafo.getGraph()));
    }

    public void testMSTForest() {
        grafo.addEdge("X", "Y", 88.0);
        expResult.addEdge("X", "Y", 88.0);
        Kruskal instance = new Kruskal(grafo, uf);
        grafo = instance.MST();
        assertThat(expResult.getGraph(), is(grafo.getGraph()));
    }
    
    public void testMSTEmptyGraph(){
    grafo=new Graph<>();
    expResult = new Graph<>();
    Kruskal instance = new Kruskal(grafo,uf);
    grafo=instance.MST();
    assertThat(expResult.getGraph(),is(grafo.getGraph()));
    }
}
