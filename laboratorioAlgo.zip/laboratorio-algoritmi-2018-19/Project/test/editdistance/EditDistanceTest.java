package editdistance;

import static junit.framework.Assert.assertEquals;
import org.junit.Test;

public class EditDistanceTest {

    private String s1, s2;
    private int ris;
    private final EditDistance a = new EditDistance();

    // Test for recursive method
    @Test
    public void replace() {
        s1 = "tassa";
        s2 = "passato";
        ris = a.editDistanceRic(s1, s2);
        assertEquals(ris, 3);
    }

    @Test
    public void isNull() {
        s1 = "casa";
        s2 = "";
        ris = a.editDistanceRic(s1, s2);
        assertEquals(ris, 4);
    }

    @Test
    public void delete() {
        s1 = "casa";
        s2 = "cassa";
        ris = a.editDistanceRic(s1, s2);
        assertEquals(ris, 1);
    }

// Test for dinamic method
    @Test
    public void not() {
        s1 = "casa";
        s2 = "";
        ris = a.editDistanceDyn(s1, s2);
        assertEquals(ris, 4);
    }

    @Test
    public void canc() {
        s1 = "casa";
        s2 = "cassa";
        ris = a.editDistanceDyn(s1, s2);
        assertEquals(ris, 1);
    }

    @Test
    public void rimp() {
        s1 = "tassa";
        s2 = "passato";
        ris = a.editDistanceDyn(s1, s2);
        assertEquals(ris, 3);
    }
    
    @Test
    public void same() {
        s1 = "pioppo";
        s2 = "pioppo";
        ris = a.editDistanceDyn(s1, s2);
        assertEquals(ris, 0);
    }
}
