
package unionfind;


public class Node <T> {
    
  private T element;
  private Node parent;
  private int rank;


  public Node(T element, Node parent, int rank) {
    this.element = element;
    this.parent = parent;
    this.rank = rank;
  }
  
  public T getElement() {
    return element;
  }

  
  public Node getParent() {
    return parent;
  }


  public int getRank() {
    return rank;
  }

 
  public void setParent(Node parent) {
    this.parent = parent;
  }
  

  public void setRank(int rank) {
    this.rank = rank;
  }
 
  @Override
  public String toString() {
    return "Node{" + "element=" + element + ", parent=" + parent.element + ", rank=" + rank + '}';
  }
  
  @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o instanceof Node){
                Node node = (Node) o;
                if (node.rank == rank && element == node.element && parent.element == node.parent.element)
                    return true;
            }

            return false;
        }
}

