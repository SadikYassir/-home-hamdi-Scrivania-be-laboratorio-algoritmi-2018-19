/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editdistance;

import java.util.Arrays;

/**
 *
 * @author Adnan
 */
public class EditDistance {

    /**
     * @param args the command line arguments
     */
    public int editDistanceRic(String s1, String s2) {
        int dNoOp, dCanc, dIns, dReplace;
        s1 = s1.toLowerCase();
        s2 = s2.toLowerCase();
        if (s1.length() == 0) {
            return s2.length();
        }
        if (s2.length() == 0) {
            return s1.length();
        }
        if (s1.charAt(0) == s2.charAt(0)) {
            dNoOp = editDistanceRic(s1.substring(1), s2.substring(1));

        } else {
            dNoOp = 2 + editDistanceRic(s1.substring(1), s2.substring(1));
        }
        dCanc = 1 + editDistanceRic(s1, s2.substring(1));
        dIns = 1 + editDistanceRic(s1.substring(1), s2);
        dReplace = 1 + editDistanceRic(s1.substring(1), s2.substring(1));
        return Math.min(Math.min(dNoOp, dCanc), Math.min(dIns, dReplace));
    }

    public int editDistanceDyn(String s1, String s2) {
        int m = s1.length();
        int n = s2.length();
        int[][] matrice = new int[m][n];
        for (int[] mem : matrice) {
            Arrays.fill(mem, -1);
        }
        return edDyn(s1, s2, matrice, m - 1, n - 1);
    }

    private int edDyn(String s1, String s2, int[][] matrice, int i, int j) {
        if (i < 0) {
            return j + 1;
        } else if (j < 0) {
            return i + 1;
        }

        if (matrice[i][j] != -1) {
            return matrice[i][j];
        }

        if (s1.charAt(i) == s2.charAt(j)) {
            matrice[i][j] = edDyn(s1, s2, matrice, i - 1, j - 1);
        } else {
            int tmp = Math.min(edDyn(s1, s2, matrice, i, j - 1), edDyn(s1, s2, matrice, i - 1, j));
            tmp = Math.min(tmp, edDyn(s1, s2, matrice, i - 1, j - 1));
            matrice[i][j] = 1 + tmp;
        }
            return matrice[i][j];
        }

    }
