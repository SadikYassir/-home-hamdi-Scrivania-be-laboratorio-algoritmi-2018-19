
package editdistance;

import java.util.ArrayList;


public class Use {

    private final EditDistance ed = new EditDistance();

    public void Usage(ArrayList<String> dictionary, ArrayList<String> correctMe) {
        ArrayList<Integer> indexOf = new ArrayList<>();
        int min;
        for (int i = 0; i < correctMe.size(); i++) {
            System.out.println("Sto valutando: " + correctMe.get(i));
            min = ed.editDistanceDyn(correctMe.get(i), dictionary.get(0));
             
            for (int j = 1; j < dictionary.size(); j++) {
                int tmp = ed.editDistanceDyn(correctMe.get(i), dictionary.get(j));

                if (tmp < min) {
                    min = tmp;
                    indexOf.clear();
                    indexOf.add(j);
                    
                } else if (tmp == min) {
                    indexOf.add(j);
                }
            }
            if (min == 0) {   //edit distance 0 quindi corretta
                System.out.println("the word : " + correctMe.get(i) + "  it's correct");
                System.out.println("--------------------------------");
            } else if (min > 0) {
                for (int j = 0; j < indexOf.size(); j++) {
                    System.out.println(dictionary.get(indexOf.get(j)));
                }

            }

        }

    }
}
