package graph;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import unionfind.UnionFindSet;

public class Usage {

    private static Graph<String, Float> createGraph(ArrayList<String> a) {
        Graph<String, Float> g = new Graph<>();
        for (int i = 0; i < a.size(); i++) {
            String[] elem = a.get(i).split(",");
            g.addEdge(elem[0], elem[1], Float.valueOf(elem[2]));
        }
        return g;
    }

    public static void main(String[] args) throws IOException {
        Graph<String, Float> g = new Graph<>();
        IOClass io = new IOClass();
        String path1 = "italian_dist_graph.csv";
        System.out.println("..Loading file " + path1);
        ArrayList<String> dist = new ArrayList<>(io.read(path1));
        System.out.println("..File " + path1 + " loaded..");
//        for (String s : dist) {
//            System.out.println("..lettura " + s + " ");
//        }
        g = createGraph(dist);
        Kruskal k = new Kruskal(g, new UnionFindSet<>());
        Graph ret = new Graph();
        ret = k.MST();
        System.out.println("num vertex: " + ret.countNodes());
        System.out.println("num edges: " + ret.countEdges());
//        System.out.println("weight: " + ret.getWeight(ret));
//        System.out.println("weight: " + ret.getWeight());
        System.out.format("Distance :%.3f", ret.getWeight()/1000);
//        System.out.println("num vertex: " + ret.countNodes());
//        Graph<String, Weight<Float>> graph = new Graph<>();
//         UnionFindSet<String> uf= new UnionFindSet<>();
//         Kruskal kruskal = new Kruskal(graph, uf);
//
//        String italianDistPath = "Resources/dataset/italian_dist_graph.csv";
//        FileReader italianDistReader= new FileReader(italianDistPath);
//        Scanner scanner = new Scanner(italianDistReader);
//
//        System.out.println("Reading file...");
//        while (scanner.hasNextLine()){
//            String str = scanner.nextLine();
//            List<String> tmp = Arrays.asList(str.split(","));
//
//            graph.addEdge(tmp.get(0), tmp.get(1), new Weight<>(Float.valueOf(tmp.get(2))));
//        }
//
//        System.out.println("Computing mst...");
//        long star = System.currentTimeMillis();
//        kruskal.MST();
//        long end = System.currentTimeMillis();
//
//        System.out.println("kruskal took " + ((end-star)/1000.0) + " seconds");

    }

}
