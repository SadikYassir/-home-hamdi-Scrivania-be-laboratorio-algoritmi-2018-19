/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author yassir
 */
public class IOClass {

    private File x;
    private FileReader fr;
    private BufferedReader re;

    public ArrayList<String> read(String path) throws FileNotFoundException, IOException {
        x = new File(path);
        ArrayList<String> a;
        if (x.exists()) {
            fr = new FileReader(x);
            re = new BufferedReader(fr);
        } else {
            System.out.println("non esiste il file");
        }
        a = new ArrayList<>();
        String line = re.readLine();
        while (line != null) {
            String[] elem = line.split("\\n");
            for (int j = 0; j < elem.length; j++) {
                a.add(elem[j]);
            }
            line = re.readLine();
        }
        re.close();
        return a;
    }

}
