package graph;

import unionfind.*;
import java.util.ArrayList;
import java.util.*;

/*
KRUSKAL(G):
1 A = ∅
2 foreach v ∈ G.V:
3    MAKE-SET(v)
4 foreach (u, v) in G.E ordered by weight(u, v), increasing:
5    if FIND-SET(u) ≠ FIND-SET(v):
6       A = A ∪ {(u, v)}
7       UNION(FIND-SET(u), FIND-SET(v))
8 return A*/
public class Kruskal<V, W> {

    private Graph<V, W> theGraph;
    private UnionFindSet<V> union;
    private ArrayList<Edge> list;
    private Graph<V, W> treeGraph;

    Kruskal(Graph<V, W> theGraph, UnionFindSet<V> union) {
        this.theGraph = theGraph;
        this.union = union;
        list = new ArrayList<>();

    }

    public Graph MST() {
        treeGraph = new Graph<>();
        if (theGraph.getNodes().isEmpty()) {
            return treeGraph;
        }
        //faccio il makeset di tutti i vertici del grafo
        for (V v : theGraph.getNodes()) {
            union.makeSet(v);
        }
        list = theGraph.allEdges();
        Collections.sort(list, new CompareEdgeWeight());

        list.forEach(el -> {
            if (union.findSet((V) el.getStartEdge()) != union.findSet((V) el.getEndEdge())) {
                treeGraph.addEdge((V) el.getStartEdge(), (V) el.getEndEdge(), (W) theGraph.getEdgeWeight((V) el.getStartEdge(), (V) el.getEndEdge()));
                union.union(union.findSet((V) el.getStartEdge()), union.findSet((V) el.getEndEdge()));
            }
        });
        return treeGraph;

    }

    @Override
    public String toString() {
        return "MST{"
                + "edges=" + treeGraph
                + '}';
    }


   /*
    public static void main(String[] args) {
        Graph<String, Double> grafo = new Graph<>();
        UnionFindSet<String> uf= new UnionFindSet<>();
        String a= "A";
        String b= "B";
        String c= "C";
        String d= "D";
        grafo.addEdge(a, b, 100.0);
        grafo.addEdge(a, c, 70.0);
        grafo.addEdge(a, d, 33.5);
        grafo.addEdge(c, d, 22.1);
        ArrayList<Edge> p = grafo.allEdges();
        Collections.sort(p, new CompareEdgeWeight());
        Kruskal k = new Kruskal(grafo, uf);
        System.out.println(k.MST());
        System.out.println(k.toString());
    }*/
    }

