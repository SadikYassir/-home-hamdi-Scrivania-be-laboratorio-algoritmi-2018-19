/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import java.util.ArrayList;
import java.util.Collections;
import unionfind.UnionFindSet;

/**
 *
 * @author soa96
 */
public class Main {

    public static void main(String[] args) {
        Graph<String, Double> grafo = new Graph<>();
        UnionFindSet<String> uf= new UnionFindSet<>();
        String a= "A";
        String b= "B";
        String c= "C";
        String d= "D";
        grafo.addEdge(a, b, 100.0);
        grafo.addEdge(a, c, 70.0);
        grafo.addEdge(a, d, 33.5);
        grafo.addEdge(c, d, 22.1);
      /*  ArrayList<Edge> p = grafo.allEdges();
        Collections.sort(p, new CompareEdgeWeight());
        System.out.println("the sorted List is: ");
        for (int i = 0; i < p.size(); i++) {
            System.out.println(p.get(i).toString());*/
        Kruskal k = new Kruskal(grafo, uf);
        System.out.println(k.MST());
        }
    }

