
package graph;

import java.util.Comparator;


public class CompareEdgeWeight implements Comparator<Edge>{
   
    @Override
    public int compare(Edge e1,Edge e2){
      if ((Double)e1.getWeightEdge()>(Double)e2.getWeightEdge())return 1;
      if ((Double)e1.getWeightEdge()<(Double)e2.getWeightEdge())return -1;
      else return 0;
    }
    
    
}

