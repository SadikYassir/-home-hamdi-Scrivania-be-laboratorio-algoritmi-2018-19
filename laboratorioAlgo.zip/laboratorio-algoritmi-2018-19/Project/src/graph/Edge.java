package graph;

public class Edge<V, W> {

    private V start;
    private V end;
    private W weight;

    public Edge(V st, V end, W weight) {
        this.start = st;
        this.end = end;
        this.weight = weight;

    }

    public V getStartEdge() {
        return start;
    }

    public V getEndEdge() {
        return end;
    }
//   public W getWeightEdge() {
//	 return weight; 
//  }

    public Double getWeightEdge() {
        return asDouble(this.weight);
    }

    private Double asDouble(Object o) {
        Double val = null;
        if (o instanceof Number) {
            val = ((Number) o).doubleValue();
        }
        return val;
    }

    public int compareTo(Edge b) {
        if ((Double) this.getWeightEdge() > (Double) b.getWeightEdge()) {
            return 1;
        } else if ((Double) this.getWeightEdge() < (Double) b.getWeightEdge()) {
            return -1;
        } else {
            return 0;
        }
    }

    @Override
    public String toString() {
        return "Edge{" + "start=" + start + ", end=" + end + ", weight=" + weight + '}';
    }

    /*public static int compare(Edge name1, Edge name2) {
        return name1  name2 ? -1 : name1 == name2 ? 0 : 1;
    }*/
}
