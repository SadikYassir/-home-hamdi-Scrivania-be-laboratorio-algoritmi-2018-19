#pragma once

typedef struct _List List;
typedef struct _Iterator Iterator;
typedef struct _Node Node;
typedef enum{false, true} Boolean;

List* list_new();

void list_free(List*);

Boolean list_is_empty(List*);
    
long list_count_elems(List*);
    
void list_insert_tail(List*, void*);

void* list_at(List*, long);
    
void list_delete_tail(List*);
    
void list_insert_at(List*, long, void*);

void list_delete_at(List*, long);

Iterator* iterator_new(List*);

void iterator_free(Iterator*);

void* iterator_curr_elem(Iterator*);

Boolean iterator_valid(Iterator*);

void iterator_next(Iterator*);







