#pragma once

typedef enum{asc, desc} OrderBy;
typedef enum{c_type, i_type, s_type, l_type, f_type, d_type} VarType;

List* merge(List*, List*, OrderBy, VarType);

int compare_elems(void*, void*, VarType);