#include "functions.h"
#include "functions_merge.h"
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>

/*
*La seguente funzione accetta in input due puntatori a void(gli elementi da confrontare) ed un tipo
* (c_type, i_type, s_type, l_type, f_type, d_type), rappresentati dall'enumeratore VarType.
*A seconda del tipo, verrà ritornato:
*   -1 se obj1 < obj2
*    0 se obj1 = obj2
*   +1 se obj1 > obj2 
*/
int compare_elems(void* obj1, void* obj2, VarType type){
    int ret;
    if(type == c_type){
        return strcmp(obj1, obj2);
    }else if(type == i_type){
        int a = *(int*)obj1;
        int b = *(int*)obj2;
        (a<b) ? (ret=-1) : ((a>b) ? (ret=1) : (ret=0)) ;
    }else if(type == s_type){
        short a = *(short*)obj1;
        short b = *(short*)obj2;
        (a<b) ? (ret=-1) : ((a>b) ? (ret=1) : (ret=0)) ;
    }else if(type == l_type){
        long a = *(long*)obj1;
        long b = *(long*)obj2;
        (a<b) ? (ret=-1) : ((a>b) ? (ret=1) : (ret=0)) ;
    }else if(type == f_type){
        float a = *(float*)obj1;
        float b = *(float*)obj2;
        (a<b) ? (ret=-1) : ((a>b) ? (ret=1) : (ret=0)) ;
    }else if(type == d_type){
        double a = *(double*)obj1;
        double b = *(double*)obj2;
        (a<b) ? (ret=-1) : ((a>b) ? (ret=1) : (ret=0)) ;
    }
    return ret;
}

/*
*La seguente funzione accetta in input il puntatore a ciascuna delle due liste su cui fare merge,
* il criterio con cui sono ordinate(asc, desc) ed il tipo degli oggetti contenuti in esse.
*Grazie all'utilizzo di iteratori, si scorrono gli elementi di ciascuna lista, inserendo in coda a 
* una nuova lista il più piccolo(se asc) o il più grande(se desc) tra i due.
*/
List* merge(List* list1, List* list2, OrderBy crit, VarType type){
    assert(crit == asc || crit == desc);
    assert(type == c_type ||type == i_type ||type == s_type ||type == l_type ||type == f_type ||type == d_type);
    List* result = list_new();
    Iterator* it1 = iterator_new(list1);
    Iterator* it2 = iterator_new(list2);
    
    while(iterator_valid(it1) && iterator_valid(it2)){
        int compRet = compare_elems(iterator_curr_elem(it1), iterator_curr_elem(it2), type);
        if((compRet <= 0 && crit == asc)||(compRet > 0 && crit == desc)){
            list_insert_tail(result, iterator_curr_elem(it1));
            iterator_next(it1);
        }else{
            list_insert_tail(result, iterator_curr_elem(it2));
            iterator_next(it2);
        }            
    }
    
    while(iterator_valid(it1)){
        list_insert_tail(result, iterator_curr_elem(it1));
        iterator_next(it1);
    }
    while(iterator_valid(it2)){
        list_insert_tail(result, iterator_curr_elem(it2));
        iterator_next(it2);
    }
    iterator_free(it1);
    iterator_free(it2);
    return result;
}