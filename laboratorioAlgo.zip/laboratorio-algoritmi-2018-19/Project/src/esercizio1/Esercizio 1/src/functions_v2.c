#include "functions.h"
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

struct _List {
    Node* head;
    Node* tail;
    long count;
};

struct _Node {
    void* elem;
    Node* next;
    Node* prev;
};

struct _Iterator {
    List* list;
    Node* current;
    long index;
};

/*
*La seguente funzione si occupa di creare una nuova lista utilizzando liste di record collegati.
*/
List* list_new() {
    List* result = (List*) malloc(sizeof(List));
    result->head = result->tail = NULL;
    result->count = 0;
    return result;
}

/*
*La seguente funzione si occupa di liberare la memoria(precedentemente allocata) della lista
* passatagli come parametro.
*/
void list_free(List* list) {
    while(list->count != 0)
        list_delete_tail(list);
    free( list );
}

/*
*La seguente funzione prende in input il puntatore a una lista, e si occupa di verificare se questa
* contiene elementi, restituendo:
*   true, se non contiene elementi;
*   false, altrimenti.
*/
Boolean list_is_empty(List* list) {
    return (list->count == 0) ? true : false; 
}

/*
*La seguente funzione restituisce il numero di elementi contenuti nella lista passatagli come
* parametro.
*/
long list_count_elems(List* list){
    return list->count;
}

/*
*La seguente funzione restituisce l'oggetto contenuto in posizione 'index' della lista  passatagli
* come parametro.
*/
void* list_at(List* list, long index){
    assert(index >= 0 && index < list->count);
    Node* currN = list->head;
    while(index != 0){
        currN=currN->next;
        index--;
    }
    return currN->elem;
}

/*
*La seguente funzione inserisce l'elemento 'obj' in coda alla lista, creando un nuovo nodo e
* gestendo opportunamente i puntatori;
*/
void list_insert_tail(List* list, void* obj) {
    Node* n = (Node*) malloc(sizeof(Node));
    n->elem = obj;
    n->next = NULL;
    if(list_is_empty(list)){
        list->head = list->tail = n;
        n->prev = NULL;
    }else{
        list->tail->next = n;
        n->prev = list->tail;
        list->tail = n;
    }
    list->count++;
}

/*
*La seguente funzione rimuove l'elemento in coda alla lista, liberando la memoria occpuata dal suo
* nodo e gestendo opportunamente i puntatori.
*/
void list_delete_tail(List* list) {
    assert(list->count > 0);
    if(list->count == 1){
        free(list->head);
        list->head = list->tail = NULL;
    }else{
    Node* toDelete = list->tail;
    list->tail = toDelete->prev;
    list->tail->next = NULL;
    free(toDelete);
    toDelete = NULL;
    }
    list->count--;
}
/*
*La seguente funzione inserisce l'elemento 'obj' nella posizione 'index' della lista, creando un
* nuovo nodo e gestendo opportunamente i puntatori.
*/
void list_insert_at(List* list, long index, void* obj) {
    assert(index >= 0 && index <= list->count);
    if(index == list->count || list_is_empty(list)){
        list_insert_tail(list, obj);
    }else if(index == 0){
        Node* newN = (Node*) malloc(sizeof(Node));
        newN->elem = obj;
        newN->prev = NULL;
        newN->next = list->head;
        list->head->prev = newN;
        list->head = newN;
        list->count++;
    }else{
        Node* newN = (Node*) malloc(sizeof(Node));
        newN->elem = obj;
        Node* currN = list->head;
        while(index != 0){
            currN=currN->next;
            index--;
        }
        currN->prev->next = newN;
        newN->prev = currN->prev;
        currN->prev = newN;
        newN->next = currN;
        list->count++;
    }
}

/*
*La seguente funzione rimuove l'elemento 'obj' nella posizione 'index' della lista, liberando la
* memoria occpuata dal suo nodo e gestendo opportunamente i puntatori.
*/
void list_delete_at(List* list, long index) {
    assert(index >= 0 && index < list->count);
    if(index == list->count-1 || list->count == 1){
        list_delete_tail(list);
    }else if(index == 0){
        Node* toDelete = list->head;
        list->head = toDelete->next;
        list->head->prev = NULL;
        free(toDelete);
        list->count--;
    }else{
        Node* toDelete = list->head;
        while(index != 0){
            toDelete=toDelete->next;
            index--;
        }
        toDelete->prev->next = toDelete->next;
        toDelete->next->prev = toDelete->prev;
        free(toDelete);
        list->count--;
    }
}

/*
*La seguente funzione si occupa di creare un nuovo iteratore capace di muoversi sulla lista
* passatagli come parametro.
*/
Iterator* iterator_new(List* list) {
    Iterator* result = (Iterator*) malloc(sizeof(Iterator));
    assert(result != NULL);
    result->list = list;
    assert(result != NULL);
    result->index = 0;
    result->current = list->head;
    return result;
}

/*
*La seguente funzione si occupa di liberare la memoria(precedentemente allocata) dell'iteratore
* passatogli come parametro.
*/
void iterator_free(Iterator* iterator) {
    free( iterator );
}

/*
*La seguente funzione restituisce l'elemento della lista, puntato attualmente dall'iteratore.
*/
void* iterator_curr_elem(Iterator* iterator){
    return iterator->current->elem;
}

/*
*La seguente funzione si occupa di verificare se l'iteratore è ancora valido nella sua posizione
* attuale. Restituisce:
*   true, se l'iteratore si trova in una posizione valida;
*   false, altrimenti.
*/
Boolean iterator_valid(Iterator* iterator){
    return (iterator->index < iterator->list->count) ? true : false;
}

/*
*La seguente funzione si occupa di incrementare l'iteratore, facendolo puntare alla posizione
* successiva rispetto quella attuale.
*/
void iterator_next(Iterator* iterator){
    iterator->current = iterator->current->next;
    iterator->index++;
}