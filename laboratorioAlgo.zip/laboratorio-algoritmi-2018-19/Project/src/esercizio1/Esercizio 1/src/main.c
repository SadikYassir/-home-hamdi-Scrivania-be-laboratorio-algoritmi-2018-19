#include "unity.h"
#include <string.h>
#include "functions.h"
#include "functions_merge.h"
#include <stdio.h>

static List* make_fixtures(){
    List* list = list_new();
    list_insert_tail(list, "a");
    list_insert_tail(list, "b");
    list_insert_tail(list, "c");
    list_insert_tail(list, "d");
    return list;
}

static List* make_fixtures_1(){
    List* list = list_new();
    list_insert_tail(list, "a");
    list_insert_tail(list, "b");
    list_insert_tail(list, "d");
    list_insert_tail(list, "z");
}

static List* make_fixtures_2(){
    List* list = list_new();
    list_insert_tail(list, "b");
    list_insert_tail(list, "c");
    list_insert_tail(list, "e");
    list_insert_tail(list, "f");
}

static void test_list_new(){
    List* list = list_new();
    TEST_ASSERT_EQUAL(true, list_is_empty(list));
    list_free(list);
}

static void test_list_at(){
    List* list = make_fixtures();
    TEST_ASSERT_EQUAL("a", list_at(list, 0));
    TEST_ASSERT_EQUAL("d", list_at(list, 3));
    list_free(list);
}

static void test_list_is_empty(){
    List* list = list_new();
    TEST_ASSERT_EQUAL(true, list_is_empty(list));
    list_insert_tail(list, "e");
    TEST_ASSERT_EQUAL(false, list_is_empty(list));
    list_delete_tail(list);
    TEST_ASSERT_EQUAL(true, list_is_empty(list));
    list_free(list);
}

static void test_list_count_elems(){
    List* list = make_fixtures();
    TEST_ASSERT_EQUAL(4, list_count_elems(list));
    list_free(list);
}

static void test_list_insert_tail(){
    List* list = make_fixtures();
    list_insert_tail(list, "e");
    TEST_ASSERT_EQUAL("e", list_at(list, 4));
    list_insert_tail(list, "f");
    list_insert_tail(list, "g");
    TEST_ASSERT_EQUAL("g", list_at(list, 6));
    list_free(list);
}

static void test_list_delete_tail(){
    List* list = make_fixtures();
    list_delete_tail(list);
    TEST_ASSERT_EQUAL(3, list_count_elems(list));
    list_delete_tail(list);
    list_delete_tail(list);
    list_delete_tail(list);
    TEST_ASSERT_EQUAL(0, list_count_elems(list));
    list_free(list);
}

static void test_list_insert_at() {
    List* list = make_fixtures();
    //inserisco in testa alla lista una "e"
    list_insert_at(list, 0, "e");
    //e a b c d
    TEST_ASSERT_EQUAL("e", list_at(list, 0));
    //inserisco in coda alla lista una "f"
    list_insert_at(list, 5, "f");
    //e a b c d f
    TEST_ASSERT_EQUAL("f", list_at(list, 5));
    //inserisco in posizione 2 una "g"
    list_insert_at(list, 2, "g");
    //e a g b c d f
    TEST_ASSERT_EQUAL("e", list_at(list, 0));
    TEST_ASSERT_EQUAL("a", list_at(list, 1));
    TEST_ASSERT_EQUAL("g", list_at(list, 2));
    TEST_ASSERT_EQUAL("b", list_at(list, 3));
    TEST_ASSERT_EQUAL("c", list_at(list, 4));
    TEST_ASSERT_EQUAL("d", list_at(list, 5));
    TEST_ASSERT_EQUAL("f", list_at(list, 6));
    TEST_ASSERT_EQUAL(7, list_count_elems(list));
    list_free(list);
}

static void test_list_delete_at() {
    List* list = make_fixtures();
    //elimino l'ultimo elemento della lista
    list_delete_at(list, 3);
    //a b c
    TEST_ASSERT_EQUAL(3, list_count_elems(list));
    //elimino il primo elemento della lista
    list_delete_at(list, 0);
    //b c
    TEST_ASSERT_EQUAL("b", list_at(list, 0));
    TEST_ASSERT_EQUAL("c", list_at(list, 1));
    list_free(list);
}

static void test_iterator_new(){
    List* list = make_fixtures();
    Iterator* it= iterator_new(list);
    TEST_ASSERT_NOT_EQUAL(NULL, it);
    list_free(list);
    iterator_free(it);
}

static void test_iterator_curr_elem(){
    List* list = make_fixtures();
    Iterator* it= iterator_new(list);
    //l'iteratore allinizio ha indice 0, cioè punta all'elemento 'a';
    TEST_ASSERT_EQUAL("a", iterator_curr_elem(it));
    
    list_free(list);
    iterator_free(it);    
}

static void test_iterator_valid(){
    List* list = make_fixtures();
    Iterator* it= iterator_new(list);
    
    TEST_ASSERT_EQUAL(true, iterator_valid(it));
    iterator_next(it);
    TEST_ASSERT_EQUAL(true, iterator_valid(it));
    iterator_next(it);
    TEST_ASSERT_EQUAL(true, iterator_valid(it));
    iterator_next(it);
    TEST_ASSERT_EQUAL(true, iterator_valid(it));
    iterator_next(it);
    TEST_ASSERT_EQUAL(false, iterator_valid(it));
    list_free(list);
    iterator_free(it);
}

static void test_iterator_next(){
    List* list = make_fixtures();
    Iterator* it= iterator_new(list);
    TEST_ASSERT_EQUAL("a", iterator_curr_elem(it)); 
    iterator_next(it);
    TEST_ASSERT_EQUAL("b", iterator_curr_elem(it));
    iterator_next(it);
    TEST_ASSERT_EQUAL("c", iterator_curr_elem(it));
    iterator_next(it);
    TEST_ASSERT_EQUAL("d", iterator_curr_elem(it));
    //se provo a incrementare ancora, siccome andrei oltre la dimensione, rimane fermo all'ìultimo elemento
    iterator_next(it);
    TEST_ASSERT_EQUAL(false, iterator_valid(it));
    list_free(list);
    iterator_free(it); 
}

static void test_all(){
    List* list = make_fixtures();
    Iterator* it= iterator_new(list);
    
    iterator_next(it);//a [b] c d
    iterator_next(it);//a b [c] d
    iterator_next(it);//a b c [d] 
    TEST_ASSERT_EQUAL("d", iterator_curr_elem(it));
    list_insert_tail(list, "e");//a b c [d] e
    iterator_next(it);//a b c d [e]
    TEST_ASSERT_EQUAL("e", iterator_curr_elem(it));
    list_delete_tail(list);//a b c d [-]
    //dopo aver eliminato l'elemento cui puntava l'iteratore, l'iteratore non è più valido
    TEST_ASSERT_EQUAL(false, iterator_valid(it));
    list_free(list);
    iterator_free(it); 
}

static void test_merge_1(){
    List* list1 = make_fixtures_1();//a b d z
    List* list2 = make_fixtures_2();//b c e f
    
    List* list3 = merge(list1, list2, asc, c_type);//a b b c d e f z
    
    TEST_ASSERT_EQUAL("a", list_at(list3, 0));
    TEST_ASSERT_EQUAL("b", list_at(list3, 1));
    TEST_ASSERT_EQUAL("b", list_at(list3, 2));
    TEST_ASSERT_EQUAL("c", list_at(list3, 3));
    TEST_ASSERT_EQUAL("d", list_at(list3, 4));
    TEST_ASSERT_EQUAL("e", list_at(list3, 5));
    TEST_ASSERT_EQUAL("f", list_at(list3, 6));
    TEST_ASSERT_EQUAL("z", list_at(list3, 7));   
    list_free(list1);
    list_free(list2);
    list_free(list3);
}

static void test_merge_2(){
    List* list1 = list_new();
    int i = 1;
    int* a = &i;
    int j = 2;
    int* b = &j;
    int k = 4;
    int* c = &k;
    int l = 10;
    int* d = &l;
    list_insert_tail(list1, a);
    list_insert_tail(list1, b);
    list_insert_tail(list1, c);
    list_insert_tail(list1, d);
    
    List* list2 = list_new();
    int m = 2;
    int* e = &m;
    int n = 3;
    int* f = &n;
    int o = 4;
    int* g = &o;
    int p = 8;
    int* h = &p;
    list_insert_tail(list2, e);
    list_insert_tail(list2, f);
    list_insert_tail(list2, g);
    list_insert_tail(list2, h);
    
    List* list3 = merge(list1, list2, asc, i_type);
    
    TEST_ASSERT_EQUAL(a, list_at(list3, 0));
    TEST_ASSERT_EQUAL(b, list_at(list3, 1));
    TEST_ASSERT_EQUAL(e, list_at(list3, 2));
    TEST_ASSERT_EQUAL(f, list_at(list3, 3));
    TEST_ASSERT_EQUAL(c, list_at(list3, 4));
    TEST_ASSERT_EQUAL(g, list_at(list3, 5));
    TEST_ASSERT_EQUAL(h, list_at(list3, 6));
    TEST_ASSERT_EQUAL(d, list_at(list3, 7));
    
    list_free(list1);
    list_free(list2);
    list_free(list3);
}

static void test_merge_3(){
    List* list1 = list_new();
    double i = 1.056;
    double* a = &i;
    double j = 2.323;
    double* b = &j;
    double k = 4.43333;
    double* c = &k;
    double l = 10.534;
    double* d = &l;
    list_insert_tail(list1, a);
    list_insert_tail(list1, b);
    list_insert_tail(list1, c);
    list_insert_tail(list1, d);
    
    List* list2 = list_new();
    double m = 2.323;
    double* e = &m;
    double n = 3;
    double* f = &n;
    double o = 4.44;
    double* g = &o;
    double p = 8.5;
    double* h = &p;
    list_insert_tail(list2, e);
    list_insert_tail(list2, f);
    list_insert_tail(list2, g);
    list_insert_tail(list2, h);
    
    List* list3 = merge(list1, list2, asc, d_type);
    
    TEST_ASSERT_EQUAL(a, list_at(list3, 0));
    TEST_ASSERT_EQUAL(b, list_at(list3, 1));
    TEST_ASSERT_EQUAL(e, list_at(list3, 2));
    TEST_ASSERT_EQUAL(f, list_at(list3, 3));
    TEST_ASSERT_EQUAL(c, list_at(list3, 4));
    TEST_ASSERT_EQUAL(g, list_at(list3, 5));
    TEST_ASSERT_EQUAL(h, list_at(list3, 6));
    TEST_ASSERT_EQUAL(d, list_at(list3, 7));
    
    list_free(list1);
    list_free(list2);
    list_free(list3);
}

static void test_merge_4(){
    List* list1 = list_new();
    double i = 1.056;
    double* a = &i;
    double j = 2.323;
    double* b = &j;
    double k = 4.43333;
    double* c = &k;
    double l = 10.534;
    double* d = &l;
    list_insert_tail(list1, d);
    list_insert_tail(list1, c);
    list_insert_tail(list1, b);
    list_insert_tail(list1, a);
    
    List* list2 = list_new();
    double m = 2.323;
    double* e = &m;
    double n = 3;
    double* f = &n;
    double o = 4.44;
    double* g = &o;
    double p = 8.5;
    double* h = &p;
    list_insert_tail(list2, h);
    list_insert_tail(list2, g);
    list_insert_tail(list2, f);
    list_insert_tail(list2, e);
    
    List* list3 = merge(list1, list2, desc, d_type);
    
    TEST_ASSERT_EQUAL(d, list_at(list3, 0));
    TEST_ASSERT_EQUAL(h, list_at(list3, 1));
    TEST_ASSERT_EQUAL(g, list_at(list3, 2));
    TEST_ASSERT_EQUAL(c, list_at(list3, 3));
    TEST_ASSERT_EQUAL(f, list_at(list3, 4));
    TEST_ASSERT_EQUAL(e, list_at(list3, 5));
    TEST_ASSERT_EQUAL(b, list_at(list3, 6));
    TEST_ASSERT_EQUAL(a, list_at(list3, 7));
    list_free(list1);
    list_free(list2);
    list_free(list3);
}


int main() {
    UNITY_BEGIN();

    RUN_TEST(test_list_new);
    RUN_TEST(test_list_is_empty);
    RUN_TEST(test_list_at);
    RUN_TEST(test_list_count_elems);
    RUN_TEST(test_list_insert_tail);
    RUN_TEST(test_list_delete_tail);
    RUN_TEST(test_list_insert_at);
    RUN_TEST(test_list_delete_at);
    RUN_TEST(test_iterator_new);
    RUN_TEST(test_iterator_curr_elem);
    RUN_TEST(test_iterator_valid);
    RUN_TEST(test_iterator_next);
    RUN_TEST(test_all);
    RUN_TEST(test_merge_1);
    RUN_TEST(test_merge_2);
    RUN_TEST(test_merge_3);
    RUN_TEST(test_merge_4);

    return UNITY_END();
    
}