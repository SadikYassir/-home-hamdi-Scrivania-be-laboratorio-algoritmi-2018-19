/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editdistance;

import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author yassir

 */
public class ReadFile {

    private static File x;
    private static FileReader fr;
    private static BufferedReader re;

    public static ArrayList<String> read(String path) throws FileNotFoundException, IOException {
        x = new File(path);
        ArrayList<String> a;
        if (x.exists()) {
            fr = new FileReader(x);
            re = new BufferedReader(fr);
        } else {
            System.out.println("file doesn't exist");
        }
        a = new ArrayList<>();
        String line = re.readLine();
        for (int i = 0; line != null; i++) {
            String[] elem = line.split("\\W+");
            for (int j = 0; j < elem.length; j++) {
                a.add(elem[j]);
            }
            line = re.readLine();
        }
        fr.close();
        return a;
    }

    public static void main(String[] args) throws IOException {
        System.out.println("inizio lettura file...");
        ArrayList<String> d = read("dictionary.txt");
        ArrayList<String> c= read("correctMe.txt");  
        Use u = new Use();
        u.Usage(d, c);
        
       /* System.out.println(res.size());
        for (String tmp : res) {
            System.out.println(tmp);
            System.out.println(tmp.length());
        }
        */
    }
}
