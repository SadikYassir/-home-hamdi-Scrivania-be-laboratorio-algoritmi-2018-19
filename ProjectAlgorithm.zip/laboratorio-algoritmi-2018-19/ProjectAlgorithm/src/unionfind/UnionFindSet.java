package unionfind;

import java.util.HashMap;
import java.util.Map;

public class UnionFindSet<T> {
   public final Map<T, Node> map ;

      public UnionFindSet(){
        this.map = new HashMap<>() ;
    }
    public void makeSet(T o) {
        Node n = new Node(o, null, 0);
        n.setParent(n);
        map.put(o, n);

    }

    public void union(T x, T y) {
        T fatherY = findSet(y);
        T fatherX = findSet(x);
        Node a = map.get(fatherX);
        Node b = map.get(fatherY);
        if (a.getRank() > b.getRank()) {

            b.setParent(map.get(x));
        } else if (a.getRank() < b.getRank()) {
            a.setParent(map.get(y));

        } else {
            a.setRank(+1);
            b.setParent(map.get(x));
        }
    
    }

    public T findSet(T o) {
        Node c = map.get(o);
        if (c == null) {
            makeSet(o);
            Node absent = map.get(o);
            Node result = findSet(absent);
            return (T) result.getElement();
        } else {
            Node result = findSet(c);
            return (T) result.getElement();
        }
    }

    public Node findSet(Node node) {
        if (node != node.getParent()) {
            node.setParent(findSet(node.getParent()));
        }
        return node.getParent();

    }
}
