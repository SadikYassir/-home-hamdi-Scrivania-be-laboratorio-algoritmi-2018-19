#include "functions.h"
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

struct _List {
    void** array;
    long capacity;
    long count; // numero di elementi presenti
};

struct _Iterator {
    List* list;
    long index;
};

/*
*La seguente funzione si occupa di creare una nuova lista utilizzando un array dinamico.
*/
List* list_new() {
    List* result = (List*) malloc(sizeof(List));
    assert(result != NULL);//assert serve per il testing. Controllo che ci sia spazio
    result->array = (void**) malloc(sizeof(void*) * (unsigned long) 1);
    assert(result->array != NULL);
    result->capacity = 1;
    result->count = 0;
    return result;
}

/*
*La seguente funzione si occupa di liberare la memoria(precedentemente allocata) della lista
* passatagli come parametro.
*/
void list_free(List* list) {
    free( list->array );
    free( list );
}

/*
*La seguente funzione prende in input il puntatore a una lista, e si occupa di verificare se questa
* contiene elementi, restituendo:
*   true, se non contiene elementi;
*   false, altrimenti.
*/
Boolean list_is_empty(List* list) {
    return (list->count == 0) ? true : false; 
}

/*
*La seguente funzione restituisce il numero di elementi contenuti nella lista passatagli come
* parametro.
*/
long list_count_elems(List* list) {
    return  list->count;
}

/*
*La seguente funzione restituisce l'oggetto contenuto in posizione 'index' della lista  passatagli
* come parametro.
*/
void* list_at(List* list, long index) {
    assert(index >= 0 && index < list->count);
    return list->array[index];
}

/*
*La seguente funzione inserisce l'elemento 'obj' in coda alla lista, riallocando opportunamente 
* l'array nel caso in cui sia pieno.
*/
void list_insert_tail(List* list, void* obj) {
    long i = list->count;
    if(i == list->capacity){
        list->array = (void **) realloc(list->array, sizeof(void*) * list->capacity * 2);
        list->capacity *= 2;
    }
    list->array[i] = obj;  
    list->count++;
}

/*
*La seguente funzione rimuove l'elemento in coda alla lista, riallocando opportunamente l'array nel
* caso in cui il numero di elementi sia inferiore alla capacità/2.
*/
void list_delete_tail(List* list) {
    long i = list->count;
    assert(i>0);
    list->count--;
    if(i <= list->capacity/2){
        list->array = (void **) realloc(list->array, sizeof(void*) * list->capacity / 2);
        list->capacity /= 2;
    }
}

/*
*La seguente funzione inserisce l'elemento 'obj' nella posizione 'index' della lista, riallocando
* opportunamente l'array nel caso in cui sia pieno.
*Gli elementi successivi verrano spostati a destra opportunamente, in modo da rimanere nello
* stesso ordine.
*/
void list_insert_at(List* list, long index, void* obj) {
    assert(index >= 0 && index <= list->count);
    if(list->count == list->capacity){
        list->array = (void **) realloc(list->array, sizeof(void*) * list->capacity * 2);
        list->capacity *= 2;
    }
    for(long i = list->count -1; i >= index; i--)
        list->array[i+1] = list->array[i];
    list->array[index] = obj;
    list->count++;
}

/*
*La seguente funzione rimuove l'elemento 'obj' nella posizione 'index' della lista, riallocando
* opportunamente l'array nel caso in cui il numero di elementi sia inferiore alla capacità/2.
*Gli elementi successivi verrano spostati a sinistra opportunamente, in modo da rimanere nello
* stesso ordine.
*/
void list_delete_at(List* list, long index) {
    assert(index >= 0 && index < list->count);
    for(long i=index; i < list->count-1; i++)
        list->array[i] = list->array[i+1];
    list->count--;
    if(list->count <= list->capacity/2){
        list->array = (void **) realloc(list->array, sizeof(void*) * list->capacity / 2);
        list->capacity /= 2;
    }
}

/*
*La seguente funzione si occupa di creare un nuovo iteratore capace di muoversi sulla lista
* passatagli come parametro.
*/
Iterator* iterator_new(List* list) {
    Iterator* result = (Iterator*) malloc(sizeof(Iterator));
    assert(result != NULL);
    result->list = list;
    assert(result != NULL);
    result->index = 0;
    return result;
}

/*
*La seguente funzione si occupa di liberare la memoria(precedentemente allocata) dell'iteratore
* passatogli come parametro.
*/
void iterator_free(Iterator* iterator) {
    free( iterator );
}

/*
*La seguente funzione restituisce l'elemento della lista, puntato attualmente dall'iteratore.
*/
void* iterator_curr_elem(Iterator* iterator){
    return iterator->list->array[iterator->index];
}

/*
*La seguente funzione si occupa di verificare se l'iteratore è ancora valido nella sua posizione
* attuale. Restituisce:
*   true, se l'iteratore si trova in una posizione valida;
*   false, altrimenti.
*/
Boolean iterator_valid(Iterator* iterator){
    return (iterator->index < iterator->list->count) ? true : false;
}

/*
*La seguente funzione si occupa di incrementare l'iteratore, facendolo puntare alla posizione
* successiva rispetto quella attuale.
*/
void iterator_next(Iterator* iterator){
    iterator->index++;
}