package graph;

import java.util.*;

public class Graph<V, W> {

    private HashMap<V, HashMap<V, W>> edges;
    private boolean direct;

    /* Constructor that creates a new Graph
    
     */
    public Graph() {
        this.edges = new HashMap<>();
        direct = false;
    }

    /*
      Constructor that creates a new graph direct or not direct , by default direct is false 
     */
    public Graph(boolean direct) {
        this.edges = new HashMap<>();
        this.direct = direct;
    }

    /* 
	Method that adds a new Vertex in the Graph in O(1),if it don't exist   
     */
    public void addNode(V node) {
        edges.putIfAbsent(node, new HashMap<>());
    }

    /*
	Method that add a new Edge in the Graph in O(1), if it don't exist . If the Graph in not direct
	they will be created two edges :start-->end and end-->start
     */
    public void addEdge(V start, V end, W weight) {
        if (!edges.containsKey(start)) {
            addNode(start);
        }
        if (!edges.containsKey(end)) {
            addNode(end);
        }
        if (!direct) {
            edges.get(end).putIfAbsent(start, weight);
            edges.get(start).putIfAbsent(end, weight);

        } else if (direct) {
            edges.get(start).putIfAbsent(end, weight);
        }

    }

    /*
     Method that prints the whole Graph
     */
    public void stamp() {
        System.out.println("GRAPH");
        for (V tmp : edges.keySet()) {
            if (edges.containsKey(tmp)) {
                System.out.println(" KEY " + tmp + " --> ");
                for (V tmp2 : edges.get(tmp).keySet()) {
                    System.out.println(" (" + tmp2 + ", "
                            + edges.get(tmp).get(tmp2) + ")");
                }
            }
        }
        System.out.println();
    }

    /*
        Method that verifies if the Graph is directed in O(1)
     */
    public boolean isDirect() {
        return this.direct;
    }

    /*
        Method that verifies if the Graph contains a Vertex in O(1)
     */
    public boolean containsNode(V node) {
        return edges.containsKey(node);
    }

    /*
       Method that verifies if the graph contains an Edge in O(1)
     */
    public boolean containsEdge(V start, V end) {
        if (!this.direct) {
            return edges.get(start).containsKey(end) && edges.get(end).containsKey(start);
        } else {
            return edges.get(start).containsKey(end);
        }

    }

    /*
    Method that removes a Vertex in O(n)
     */
    public void removeNode(V node) {
        edges.remove(node);
        for (HashMap search : edges.values()) {
            search.remove(node);
        }
    }

    /* 
    Method that removes an Edge in O(1)
     */
    public boolean removeEdge(V start, V end) {
        if (this.direct) {
            return edges.remove(start, end);
        } else {
            return edges.remove(start, end) && edges.remove(end, start);
        }
    }

    /*
    Method that determinates the number of Vertices in the Graph , in O(n)
     */
    public int countNodes() {
        return edges.keySet().size();

    }

    /*
    Method that determinates the number of Edges in the Graph, in O(n)
     */
    public int countEdges() {
        int sum = 0;
        for (V tmp : edges.keySet()) {
            sum += edges.get(tmp).keySet().size();
        }
        if (!this.direct) {
            return sum / 2;
        } else {
            return sum;
        }
    }

    /*
        Method that returns all the Vertices of the Graph ,in O(n).
     */
    public Set<V> getNodes() {
        return edges.keySet();
    }

    /*
       Method that returns all the Edges of the Graph like a HashMap,in O(n)
     */
    public HashMap<Edge, W> getAllEdges() {
        HashMap<Edge, W> allE = new HashMap<>();
        for (V start : edges.keySet()) {
            HashMap<V, W> hM = getNeighbors(start);
            for (V end : hM.keySet()) {
                allE.put(new Edge(start, end, getEdgeWeight(start, end)), getEdgeWeight(start, end));
            }
        }
        return allE;
    }

    /*
     Method that returns all the Edges of the Graph like a ArrayList
     */
    public ArrayList<Edge> allEdges() {
        ArrayList<Edge> allE = new ArrayList();
        for (V start : edges.keySet()) {
            HashMap<V, W> tmp = getNeighbors(start);
            for (V end : tmp.keySet()) {
                allE.add(new Edge(start, end, getEdgeWeight(start, end)));
            }
        }
        return allE;
    }

    /* 
    Method that returns all the Neighbors of a Vertex , in O(1)
     */
    public HashMap<V, W> getNeighbors(V node) {
        return edges.get(node);
    }

    /* 
    Method that returns the Weight of an Edge 
     */
    public W getEdgeWeight(V start, V end) {
        W d = null;
        if (!edges.containsKey(start) || !edges.containsKey(end)) {
            throw new IllegalArgumentException("Vertex doesn't exist.");
        } else if ((edges.containsKey(start) && edges.containsKey(end))) {
            d = edges.get(start).get(end);
        }
        return d;
    }

    public Map<V, HashMap<V, W>> getGraph() {
        return edges;
    }

    private Double asDouble(Object o) {
        Double val = null;
        if (o instanceof Number) {
            val = ((Number) o).doubleValue();
        }
        return val;
    }

    /*
    Method that returns the Weight of the whole Graph
     */
    public Double getWeight() {
        double s = 0;
        for (HashMap<V, W> vertici : edges.values()) {
            for (W w : vertici.values()) {
                if (w == null) {
                    return null;
                }
                s += asDouble(w);
            }
        }
        if (this.isDirect()) {
            return s;
        } else {
            return s / 2;
        }
    }

    @Override
    public String toString() {
        return "Graph{"
                + "edges=" + edges
                + '}';
    }

}
